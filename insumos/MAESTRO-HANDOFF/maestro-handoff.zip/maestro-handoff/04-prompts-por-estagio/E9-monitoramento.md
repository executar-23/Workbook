# E9 — Monitoramento e melhoria  (BPM fase 8 · medir, auditar, versionar)

## OBJECTIVE
Manter o sistema honesto ao longo do tempo: medir, detectar drift, corrigir sem apagar histórico.

## CONTEXT
Comportamento real difere dos testes; monitorar qualidade, custo, segurança e drift.

## INPUT
Ledger, logs, métricas de C-03.

## CONSTRAINTS
Skills: `operations:status-report`, `operations:process-optimization`, `engineering:tech-debt`, `engineering:incident-response` (só se houver incidente). **Mudança de contrato = change control** (`CURRENT→EVIDENCE→CONFLICT→PROPOSED_CHANGE→IMPACT→REVIEW_REQUIRED→STATUS`).

## EXECUTION
1. Cadência de revisão (`A DEFINIR` com o usuário): métricas, drift de skills (EV-008), retrabalho, overkill.
2. Auditoria periódica dos contratos e do ledger (um ledger só — EV-012).
3. Melhorias entram como novos nós; **nada apaga histórico** (I-10).
4. F7 final: relatório de skills e capacidades atualizado.

## OUTPUT CONTRACT
`07-execucao/E9-monitoramento.md` + relatório periódico.

## VALIDATION
Métricas coletadas em ≥ 1 ciclo; um caso de drift simulado detectado.

## STOP CONDITIONS
Concluir = processo de melhoria rodando 1 ciclo com evidência.
