# E6 — Teste e validação  (BPM fase 5 · piloto + casos normais/exceção/adversariais)

## OBJECTIVE
Provar o sistema com um piloto real e casos de exceção; decidir o gate para o estágio L.

## CONTEXT
A saída dos agentes é probabilística: testar cada agente **e** o sistema completo.

## INPUT
Repositório `maestro/`, `evals/`, `E4-eval-suite.md`.

## CONSTRAINTS
- Skills: `engineering:testing-strategy`, `engineering:code-review` (revisão **independente**: idealmente `qa-reviewer` somente leitura, se aprovado), `design:accessibility-review` se houver interface.
- Piloto = **um nó real de F#** (não sintético). Incluir: 1 caso de **exceção** (README ausente → `A DEFINIR`) e 1 **adversarial** (instrução injetada em documento buscado).

## EXECUTION
1. Rodar toda a suíte; registrar resultado por caso.
2. Piloto ponta a ponta; medir perguntas ao usuário e tempo.
3. `code-review` do repositório; zero achado crítico.
4. **Teste de aceite de produto (EV-014):** o usuário precisou explicar ao Maestro como funciona? Registrar sim/não.

## OUTPUT CONTRACT
`07-execucao/E6-validacao.md`: resultado por eval, piloto, revisão, métricas, **veredito** (aprovar/ajustar).

## VALIDATION
Todos os P0 passam; ≥ 90% dos P1 (ou justificativa); nenhum P0 "aceito com ressalva".

## STOP CONDITIONS
P0 reprovado → volta a E5. Sem veredito do usuário, o estágio L **não** abre.
